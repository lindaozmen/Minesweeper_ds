#define MOD_FLATOUTLIES	0
#define MSL_NSONGS	1
#define MSL_NSAMPS	0
#define MSL_BANKSIZE	1
